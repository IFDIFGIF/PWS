import pygame,os

a = input("load, create or delete? (l/c/d) >")
if a == 'l':
    n = input("load map: ")
    map = open("maps\{}\map.txt".format(n),'r+')
    betamap = open("maps\{}\\beta.txt".format(n), 'r+')
    alphamap = open("maps\{}\\alpha.txt".format(n),'r+')
    boundmap = open("maps\{}\\bounds.txt".format(n),'r+')
    objects = open("maps\{}\objects.txt".format(n), 'r+')
elif a == 'c':
    n = input("name of new map: ")
    if not os.path.exists(os.getcwd()+'/maps/{}/'.format(n)):
        os.makedirs(os.getcwd()+'/maps/{}/'.format(n))
    map = open("maps\{}\map.txt".format(n),'w+')
    betamap = open("maps\{}\\beta.txt".format(n), 'w+')
    alphamap = open("maps\{}\\alpha.txt".format(n),'w+')
    boundmap = open("maps\{}\\bounds.txt".format(n),'w+')
    objects = open("maps\{}\objects.txt".format(n),'w+')
    w,h = int(input("width = "))*16,int(input("height = "))*16
    map.write('{}.{}\n'.format(w,h))
    alphamap.write('{}.{}\n'.format(w, h))
    betamap.write('{}.{}\n'.format(w, h))
    for c in range(int(h/16)):
        for i in range(int(w/16)-1):
            map.write('0,1.')
        map.write('0,1\n')
    for c in range(int(h/16)):
        for i in range(int(w/16)-1):
            alphamap.write('0,0.')
        alphamap.write('0,0\n')
    for c in range(int(h/16)):
        for i in range(int(w/16)-1):
            boundmap.write('0')
        boundmap.write('0\n')
    for c in range(int(h/16)):
        for i in range(int(w/16)-1):
            betamap.write('0,0.')
        betamap.write('0,0\n')
    objects.write('objectPlayerPos;[0,0];\n'.format(n))
    map.close()
    alphamap.close()
    betamap.close()
    objects.close()
    boundmap.close()
    quit()
elif a == 'd':
    n = input("delete map: ")
    os.remove("maps\{}\map.txt".format(n))
    os.remove("maps\{}\\beta.txt".format(n))
    os.remove("maps\{}\\alpha.txt".format(n))
    os.remove("maps\{}\\bounds.txt".format(n))
    os.remove("maps\{}\objects.txt".format(n))
    quit()
else:
    quit()

pygame.init()

screen = pygame.display.set_mode((640+8*16*2,640))
pygame.display.set_caption("Map Editor")
clock = pygame.time.Clock()
done = False

campos = [0,0]
pointerpos = [0,0]

tileset = pygame.image.load("textures/tileset-blackvolution.png").convert_alpha()
good = pygame.image.load("textures/good.png").convert_alpha()
bad = pygame.image.load("textures/bad.png").convert_alpha()
warp = pygame.image.load("textures/warp.png").convert_alpha()
player = pygame.image.load("textures/player-kaori.png").convert_alpha()

mapl = map.readlines()
bmapl = boundmap.readlines()
bemapl = betamap.readlines()
amapl = alphamap.readlines()
omapl = objects.readlines()

font = pygame.font.SysFont("arial",30)
font2 = pygame.font.SysFont("arial",15)
stateblit = font.render("editing groundmap",False,(255,255,255))
state = 'groundmap'

zoom = 4
scrollpos = 0

def drawmap(map):
    for y in range(len(map) - 1):
        for x in range(len(map[y + 1].split("."))):
            locx = int(map[y + 1].split(".")[x].split(",")[0])
            locy = int(map[y + 1].split(".")[x].split(",")[1])
            ttt.blit(tileset, (x * 16, y * 16), (locx * 16, locy * 16, 16, 16))

while not done:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
        if event.type == pygame.KEYDOWN:
            if pygame.key.get_pressed()[pygame.K_SPACE]:
                if pygame.key.get_pressed()[pygame.K_r]:
                    if event.key == pygame.K_UP:
                        scrollpos += 640
                        pointerpos[1] -= 20
                        if pointerpos[1] < 0:
                            pointerpos[1] = 0
                            scrollpos = 0
                    if event.key == pygame.K_DOWN:
                        scrollpos -= 640
                        pointerpos[1] += 20
                        if pointerpos[1] > 99:
                            pointerpos[1] = 99
                            scrollpos = -640*4
                else:
                    if event.key == pygame.K_UP:
                        pointerpos[1] -= 1
                        if pointerpos[1] < 40:
                            scrollpos = -640
                        if pointerpos[1] < 20:
                            scrollpos = 0
                        if pointerpos[1] < 0:
                            pointerpos[1] = 0
                    if event.key == pygame.K_DOWN:
                        pointerpos[1] += 1
                        if pointerpos[1] > 19:
                            scrollpos = -640
                        if pointerpos[1] > 39:
                            scrollpos = -640*2
                        if pointerpos[1] > 59:
                            scrollpos = -640 * 3
                        if pointerpos[1] > 79:
                            scrollpos = -640 * 4
                        if pointerpos[1] > 99:
                            pointerpos[1] = 99
                    if event.key == pygame.K_LEFT:
                        pointerpos[0] -= 1
                        if pointerpos[0] < 0:
                            pointerpos[0] = 0
                    if event.key == pygame.K_RIGHT:
                        pointerpos[0] += 1
                        if pointerpos[0] > 7:
                            pointerpos[0] = 7
            else:
                if event.key == pygame.K_z:
                    zoom *= 1.1
                if event.key == pygame.K_x:
                    zoom /= 1.1
                if event.key == pygame.K_UP:
                    campos[1] += 16 * zoom
                if event.key == pygame.K_DOWN:
                    campos[1] -= 16 * zoom
                if event.key == pygame.K_LEFT:
                    campos[0] += 16 * zoom
                if event.key == pygame.K_RIGHT:
                    campos[0] -= 16 * zoom
                if event.key == pygame.K_s:
                    map.close()
                    os.remove("maps\{}\map.txt".format(n))
                    map = open("maps\{}\map.txt".format(n), 'w+')
                    print(len(mapl))
                    for line in mapl:
                        map.write(line)
                    boundmap.close()
                    os.remove("maps\{}\\bounds.txt".format(n))
                    boundmap = open("maps\{}\\bounds.txt".format(n), 'w+')
                    for line in bmapl:
                        boundmap.write(line)
                    betamap.close()
                    os.remove("maps\{}\\beta.txt".format(n))
                    betamap = open("maps\{}\\beta.txt".format(n), 'w+')
                    for line in bemapl:
                        betamap.write(line)
                    alphamap.close()
                    os.remove("maps\{}\\alpha.txt".format(n))
                    alphamap = open("maps\{}\\alpha.txt".format(n), 'w+')
                    for line in amapl:
                        alphamap.write(line)
                    objects.close()
                    os.remove("maps\{}\\objects.txt".format(n))
                    objects = open("maps\{}\\objects.txt".format(n), 'w+')
                    for line in omapl:
                        objects.write(line)
                    print("saved!")
                if event.key == pygame.K_g:
                    state = 'groundmap'
                    stateblit = font.render("editing groundmap", False, (255, 255, 255))
                if event.key == pygame.K_b:
                    state = 'betamap'
                    stateblit = font.render("editing betamap", False, (255, 255, 255))
                if event.key == pygame.K_n:
                    state = 'boundmap'
                    stateblit = font.render("editing boundmap", False, (255, 255, 255))
                if event.key == pygame.K_a:
                    state = 'alphamap'
                    stateblit = font.render("editing alphamap", False, (255, 255, 255))
                if event.key == pygame.K_o:
                    state = 'objectmap'
                    stateblit = font.render("editing objects", False, (255, 255, 255))
        if event.type == pygame.MOUSEBUTTONDOWN:
            if state == 'groundmap':
                x = int((event.pos[0]-campos[0])/16/zoom)
                y = int((event.pos[1] - campos[1]) / 16 / zoom)
                try:
                    f = mapl[y+1].split(".")
                    if x == len(f)-1:
                        f[x] = '{},{}\n'.format(pointerpos[0],pointerpos[1])
                    else:
                        f[x] = '{},{}'.format(pointerpos[0], pointerpos[1])
                    tF = ''
                    for i in f:
                        tF += '.'
                        tF += i
                    mapl[y+1] = tF[1:]
                except IndexError:
                    pass
            elif state == 'boundmap':
                x = int((event.pos[0] - campos[0]) /16/zoom)
                y = int((event.pos[1] - campos[1]) /16/zoom)
                try:
                    f = list(bmapl[y])
                    if event.button == 1:
                        f[x] = str((int(f[x])+1)%2)
                    elif event.button == 0:
                        f[x] = str((int(f[x]) - 1) % 2)
                    bmapl[y] = "".join(f)
                except IndexError:
                    pass
            elif state == 'betamap':
                x = int((event.pos[0]-campos[0])/16/zoom)
                y = int((event.pos[1]-campos[1]) /16/zoom)
                try:
                    f = bemapl[y+1].split(".")
                    if x == len(f)-1:
                        f[x] = '{},{}\n'.format(pointerpos[0],pointerpos[1])
                    else:
                        f[x] = '{},{}'.format(pointerpos[0], pointerpos[1])
                    tF = ''
                    for i in f:
                        tF += '.'
                        tF += i
                    bemapl[y+1] = tF[1:]
                except IndexError:
                    pass
            elif state == 'alphamap':
                x = int((event.pos[0]-campos[0])/16/zoom)
                y = int((event.pos[1]-campos[1]) /16/zoom)
                try:
                    f = amapl[y+1].split(".")
                    if x == len(f)-1:
                        f[x] = '{},{}\n'.format(pointerpos[0],pointerpos[1])
                    else:
                        f[x] = '{},{}'.format(pointerpos[0], pointerpos[1])
                    tF = ''
                    for i in f:
                        tF += '.'
                        tF += i
                    amapl[y+1] = tF[1:]
                except IndexError:
                    pass

    w,h = int(mapl[0].split(".")[0]),int(mapl[0].split(".")[1])
    ttt = pygame.Surface((w,h))

    drawmap(mapl)
    drawmap(bemapl)
    e = eval(omapl[0].split(";")[1])
    ttt.blit(player, (e[0]*16-2,e[1]*-16-17), (0,0,20,25))
    drawmap(amapl)

    if state == 'boundmap':
        for y in range(len(bmapl)):
            for x in range(len(bmapl[y])):
                if bmapl[y][x] == '0':
                    ttt.blit(good, (x * 16, y * 16))
                if bmapl[y][x] == '1':
                    ttt.blit(bad, (x * 16, y * 16))

    for i in omapl[1:]:
                if i.split(';')[0] == 'objectWarp':
                        p = eval(i.split(';')[1])
                        ttt.blit(warp, (p[0]*16,p[1]*16))
                        f = pygame.font.SysFont("arial",10).render("to {}".format(i.split(';')[2]), False, (255,0,0))
                        ttt.blit(f,(8+p[0]*16-f.get_width()/2,p[1]*16+f.get_height()))

    screen.fill((0,0,20))
    screen.blit(pygame.transform.scale(ttt, (int(w*zoom),int(h*zoom))), (campos[0],campos[1]))
    pygame.draw.rect(screen, (255,0,255), (640,0,640+8*16*2-640,640))
    screen.blit(pygame.transform.scale(tileset, (8*16*2,tileset.get_height()*2)), (640,scrollpos))
    pygame.draw.rect(screen, (255,0,0), (640+pointerpos[0]*32,pointerpos[1]*32+scrollpos,32,32), 2)
    pygame.draw.line(screen,(0,255,0),(640,0),(640,640),3)
    screen.blit(stateblit,(0,0))

    p = pygame.mouse.get_pos()
    x = int((p[0] - campos[0]) / 16 / zoom)
    y = int((p[1] - campos[1]) / 16 / zoom)

    posblit = font2.render("{}, {}".format(x,y), False, (255, 255, 255), (0,0,0))
    screen.blit(posblit, (p[0]+15,p[1]))

    pygame.display.flip()
    clock.tick(60)
    
pygame.display.quit()
map.close()
alphamap.close()
betamap.close()
objects.close()
boundmap.close()
