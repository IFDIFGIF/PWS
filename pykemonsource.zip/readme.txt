THIS IS THE README OF 'Pykemon' CREATED BY 'Pyroy'
DOWNLOADED FROM github.io/pyroy/pykemon
ENJOY!

------======[Pykemon / Pythemon / Some other stupid Python-Pokemon pun]======------

"If it's one thing I learned it's that games shouldn't be made in Python." - Anonymous on Stackoverflow
Well, fuck you! I did it anyways!
So here I present: Pykemon!

------======[Contents]======------
For casual players:
1. Running Pykemon
2. Controls

For people who want to customize their game and/or want to create extra or different content for Pykemon:
!! No knowledge of Python required !!
3. Pykemon folder structure
4. The map editor
5. Editing objects.txt
6. Editing NPCs
7. Global activators

For Python developers with the source: (lol)
8. The pokepy module and the magic it contains (created by Pyroy great guy please credit him thanks)
9. main.py and its best friends maploader.py and npcloader.py
10. What the heck is battlescene.py and why is it so majestically programmed?

For adding custom pokemon or editing items or editing ingame stats and values of pokemon,
please refer to the readme in the pokepy module that came with this installation.

------======[Running Pykemon]======------
To run Pykemon as it should, use the Pykemon.exe file that came with the download.
Make sure your Pykemon folder looks as follows:

[Pykemon]
	\___[data]
	\___[maps]
	\___[npcs]
	\___[textures]
	\___jackeyfont.ttf
	\___Pykemon.exe
	\___readme.txt