import pygame

class Bounds:
        def __init__(self,b):
                self.bounds = b
        def checkBounds(self,x,y):
                y = -y
                if y in range(len(self.bounds)):
                        if x in range(len(self.bounds[0])):
                                if self.bounds[y][x] == '\n':
                                        return 1
                                else:
                                        return int(self.bounds[y][x])
                return 1

class MapLoader:
        def __init__(self):
                self.tileset = pygame.image.load("textures/tileset-blackvolution.png")
        def loadMap(self,map):
                self.map = open("maps\{}\map.txt".format(map)).readlines()
                self.drawmap = pygame.Surface((int(self.map[0].split(".")[0]),int(self.map[0].split(".")[1])))
                self.drawmap.fill((255,255,255))
                for y in range(len(self.map)-1):
                        for x in range(len(self.map[y+1].split("."))):
                                self.locx = int(self.map[y+1].split(".")[x].split(",")[0])
                                self.locy = int(self.map[y+1].split(".")[x].split(",")[1])
                                self.drawmap.blit(self.tileset,(x*16,y*16),(self.locx*16,self.locy*16,16,16))
                return self.drawmap
        def loadAlphaMap(self,map,beta=False):
                if beta:
                        self.map = open("maps\{}\\beta.txt".format(map)).readlines()
                else:
                        self.map = open("maps\{}\\alpha.txt".format(map)).readlines()
                self.drawmap = pygame.Surface((int(self.map[0].split(".")[0]), int(self.map[0].split(".")[1])))
                self.drawmap.fill((255,0,255))
                self.drawmap.set_colorkey((255,0,255))
                self.drawmap.convert_alpha()
                for y in range(len(self.map)-1):
                        for x in range(len(self.map[y+1].split("."))):
                                self.locx = int(self.map[y+1].split(".")[x].split(",")[0])
                                self.locy = int(self.map[y+1].split(".")[x].split(",")[1])
                                self.drawmap.blit(self.tileset,(x*16,y*16),(self.locx*16,self.locy*16,16,16))
                return self.drawmap
        def loadBoundsMap(self,map):
                self.map = open("maps\{}\\bounds.txt".format(map)).readlines()
                return Bounds(self.map)
        def getWarpPoints(self,map):
                self.map = open("maps\{}\objects.txt".format(map)).readlines()
                sPos = eval(self.map[0].split(';')[1])
                tA = [[sPos[0]*16,sPos[1]*-16]]
                for i in range(1,len(self.map)):
                        p = self.map[i].split(';')
                        if p[0] == 'objectWarp':
                                tA.append([[eval(p[1])[0]*16,eval(p[1])[1]*-16],str(p[2]),[eval(p[3])[0]*16,eval(p[3])[1]*-16]])
                return tA
